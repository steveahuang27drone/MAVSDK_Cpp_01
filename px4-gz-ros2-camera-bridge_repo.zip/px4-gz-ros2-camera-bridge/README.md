# px4_gz_camera_bridge

A minimal **ROS 2 Humble** launch package to bridge a **Gazebo Sim (gz)** camera (Image + CameraInfo) into ROS 2 topics for **PX4 SITL** on Ubuntu 22.04.

This repository is intentionally scoped to **a single camera** (no stereo pipeline).

## Quick start (PX4 x500_mono_cam)

### Terminal 1: Start PX4 SITL + Gazebo Sim
```bash
cd ~/0Test/PX4-Autopilot
make px4_sitl gz_x500_mono_cam
```

### Terminal 2: Bridge Image + CameraInfo into ROS 2
Recommended (more robust for Image):
```bash
source /opt/ros/humble/setup.bash
ros2 launch px4_gz_camera_bridge bridge_single_camera.launch.py \
  gz_image_topic:=/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/image \
  gz_info_topic:=/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/camera_info \
  ros_image_topic:=/camera/image_raw \
  ros_info_topic:=/camera/camera_info \
  mode:=image_bridge
```

Alternative (use only if it works for your setup):
```bash
source /opt/ros/humble/setup.bash
ros2 launch px4_gz_camera_bridge bridge_single_camera.launch.py \
  gz_image_topic:=/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/image \
  gz_info_topic:=/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/camera_info \
  ros_image_topic:=/camera/image_raw \
  ros_info_topic:=/camera/camera_info \
  mode:=parameter_bridge
```

## Build / Install (colcon)
```bash
mkdir -p ~/ros_ws/src
cd ~/ros_ws/src
# git clone this repo here
cd ~/ros_ws
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
```

## Verify
```bash
ros2 topic list | egrep "camera|image"
ros2 topic hz /camera/image_raw
ros2 topic echo /camera/camera_info --once
```

## Find gz camera topics
```bash
./scripts/find_gz_camera_topics.sh
```

## Notes
- Some Humble installs do not support `ros2 --version`. Use `ros2 doctor --report`.
- If `parameter_bridge` for `gz.msgs.Image` produces repeated warnings and no frames, use `mode:=image_bridge`.

## License
MIT
