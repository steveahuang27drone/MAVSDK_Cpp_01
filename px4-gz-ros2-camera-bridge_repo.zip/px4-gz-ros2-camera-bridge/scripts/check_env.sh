#!/usr/bin/env bash
set -euo pipefail

echo "=== OS / Kernel ==="
(lsb_release -a 2>/dev/null || cat /etc/os-release) | sed 's/^/  /'
uname -a | sed 's/^/  /'
echo

echo "=== Architecture ==="
uname -m | sed 's/^/  /'
echo

echo "=== ROS 2 (Humble) ==="
if [ -f /opt/ros/humble/setup.bash ]; then
  # shellcheck disable=SC1091
  source /opt/ros/humble/setup.bash
fi
ros2 doctor --report || true
echo

echo "--- ros_gz packages ---"
ros2 pkg list | egrep -i '^ros_gz' || true
echo

echo "--- bridge executables ---"
ros2 pkg executables | egrep -i 'ros_gz_(bridge|image)' || true
echo

echo "=== Gazebo Sim (gz) ==="
gz sim --version || true
gz sim --versions || true
echo

echo "=== Gazebo topics (camera/image) ==="
gz topic -l | egrep -i 'camera|image|camera_info' || true
