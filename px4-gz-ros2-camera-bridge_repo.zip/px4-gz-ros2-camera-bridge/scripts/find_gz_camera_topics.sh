#!/usr/bin/env bash
set -euo pipefail

echo "=== gz sim version ==="
gz sim --version || true
echo

echo "=== partition / env ==="
echo "GZ_PARTITION=${GZ_PARTITION:-<unset>}"
echo "GZ_SIM_RESOURCE_PATH=${GZ_SIM_RESOURCE_PATH:-<unset>}"
echo

echo "=== candidate camera topics (image / camera_info) ==="
gz topic -l | egrep -i 'camera|image|camera_info' || true
echo
echo "Tip: If you see no topics, ensure PX4 SITL + Gazebo Sim is running and the world is loaded."
echo "     If PX4 uses a partition, export the same GZ_PARTITION in this terminal and rerun."
