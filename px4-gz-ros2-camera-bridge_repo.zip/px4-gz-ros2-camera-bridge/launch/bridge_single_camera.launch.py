#!/usr/bin/env python3
# ROS 2 Humble compatible: avoid ConcatSubstitution and other newer APIs.

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    gz_image_topic = LaunchConfiguration("gz_image_topic")
    gz_info_topic = LaunchConfiguration("gz_info_topic")
    ros_image_topic = LaunchConfiguration("ros_image_topic")
    ros_info_topic = LaunchConfiguration("ros_info_topic")
    mode = LaunchConfiguration("mode")  # image_bridge (default) or parameter_bridge

    camera_info_bridge = ExecuteProcess(
        cmd=[
            "/bin/bash", "-lc",
            'ros2 run ros_gz_bridge parameter_bridge '
            '"${GZ_INFO_TOPIC}@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo" '
            '--ros-args -r "${GZ_INFO_TOPIC}:=${ROS_INFO_TOPIC}"'
        ],
        output="screen",
        additional_env={
            "GZ_INFO_TOPIC": gz_info_topic,
            "ROS_INFO_TOPIC": ros_info_topic,
        },
        name="gz_camera_info_bridge",
    )

    image_bridge = ExecuteProcess(
        cmd=[
            "/bin/bash", "-lc",
            'if [ "${MODE}" = "parameter_bridge" ]; then '
            '  ros2 run ros_gz_bridge parameter_bridge '
            '  "${GZ_IMAGE_TOPIC}@sensor_msgs/msg/Image[gz.msgs.Image" '
            '  --ros-args -r "${GZ_IMAGE_TOPIC}:=${ROS_IMAGE_TOPIC}"; '
            'else '
            '  ros2 run ros_gz_image image_bridge "${GZ_IMAGE_TOPIC}" '
            '  --ros-args -r "${GZ_IMAGE_TOPIC}:=${ROS_IMAGE_TOPIC}"; '
            'fi'
        ],
        output="screen",
        additional_env={
            "MODE": mode,
            "GZ_IMAGE_TOPIC": gz_image_topic,
            "ROS_IMAGE_TOPIC": ros_image_topic,
        },
        name="gz_image_bridge",
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            "gz_image_topic",
            default_value="/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/image",
            description="Gazebo (gz) image topic",
        ),
        DeclareLaunchArgument(
            "gz_info_topic",
            default_value="/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/camera_info",
            description="Gazebo (gz) camera_info topic",
        ),
        DeclareLaunchArgument(
            "ros_image_topic",
            default_value="/camera/image_raw",
            description="ROS 2 image output topic",
        ),
        DeclareLaunchArgument(
            "ros_info_topic",
            default_value="/camera/camera_info",
            description="ROS 2 camera_info output topic",
        ),
        DeclareLaunchArgument(
            "mode",
            default_value="image_bridge",
            description='Image bridging mode: "image_bridge" (default) or "parameter_bridge".',
        ),
        camera_info_bridge,
        image_bridge,
    ])
